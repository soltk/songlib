package application;

import java.io.IOException;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
// Garis Silega and Jack Davitt
public class SongLib extends Application {

	private SongList songs;
	
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Song Library");
        songs = new SongList();
        

        try {
        	FXMLLoader loader = new FXMLLoader();   
    		loader.setLocation(
    				getClass().getResource("SongListView.fxml"));
    		AnchorPane root = (AnchorPane)loader.load();
            Platform.setImplicitExit(true);
    		ListController listController = 
    				loader.getController();
    		listController.start(primaryStage, songs);

// ListController.start(primaryStage) causes the nullpointerexcpetion and all the errors
    		Scene scene = new Scene(root, 700, 500);
    		primaryStage.setScene(scene);
    		primaryStage.show(); 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        launch(args);
    }
}