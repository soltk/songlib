package application;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;


// Garis Silega and Jack Davitt
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


public class SongList {
	// Master list to hold all the songs in our library
	ObservableList<Song> songList;
	ObservableList<String> auxillaryList;
	// Single song representing the most recently deleted or edited song, allowing Undo function
	/**
	 * constructor
	 */
	public SongList() {
		this.songList = FXCollections.observableArrayList();
		this.auxillaryList = FXCollections.observableArrayList();
		
	}
	
	/**
	 * scans the text file, assigns strings to Song objects, loads Songs into songList
	 * @throws FileNotFoundException
	 */
/*	public void read() throws FileNotFoundException {
		int index = 0;
		Scanner scan = new Scanner(new File("src/application/songtext.txt"));
		while (scan.hasNext()) {
			String current = scan.next();
			System.out.println(current);
			String[] parts = current.split("," -1); // problem with delimeters 
			String sname = parts[0];
			String sartist = parts[1];
			String salbum = parts[2];
			String syear = parts[3]; 
			Song newSong = new Song(sname,sartist,salbum,syear);
			songList.add(newSong);
			auxillaryList.add(newSong.toString());
			index++;	
	}*/ 
	public void read() throws FileNotFoundException {  
	BufferedReader br =new BufferedReader(new FileReader("src/application/songtext.txt")); try {
		String line ="";
		while ((line = br.readLine()) != null) {
			String[] songDetails = new String[4];
			String[] temp = line.split(",");	//create array of song details, separated by ","
			for(int i = 0; i < temp.length; i++) {
				songDetails[i] = temp[i];
			}

			Song song = new Song(songDetails[0], songDetails[1], songDetails[2], songDetails[3]);
			songList.add(song);	//add song array entry 0 (song title) to songs list
			auxillaryList.add(song.toString());
		}

	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	} finally {
		if (br != null) {
			try {
				br.close();
			} catch (IOException e) { 
				e.printStackTrace();
			}
		}}}
	/**
	 * private use only. Inserts a song into the arraylist in sorted order.
	 * @param newSong
	 * @mutates songList
	 */
	public void insertSong(Song newSong) { 
		if(!songList.contains(newSong)) {songList.add(newSong);
		
		FXCollections.sort(songList);
		auxillaryList.add(songList.indexOf(newSong), newSong.toString());
		return;}
		else return;
	}
	public boolean check(Song n) {
		if (songList.contains(n)) return true;
		else return false;
	}
	/**
	 * Edits a song in the list with any fields that are not the empty String
	 * If the song is edited to have the same name and artist as another song, the edit fails
	 * @param oldName
	 * @param oldArtist
	 * @param newName
	 * @param newArtist
	 * @param newAlbum
	 * @param newYear
	 * @mutates undoSong, lastActionWasAdd, songList
	 */
	public int edit(String oldName, String oldArtist, String newName, String newArtist, String newAlbum, String newYear) {
		Song targetSong = new Song(oldName, oldArtist);
		int targetIndex = songList.indexOf(targetSong);
		if (targetIndex == -1) {
			return -1;
		}
		targetSong = songList.get(targetIndex);
		Song copyOfTargetSong = new Song(targetSong.getName().toString(), targetSong.getArtist().toString(), targetSong.getAlbum().toString(),
				targetSong.getYear().toString());
		
		// Set un-specified edits to old value
		if (newName.equals("")) newName = targetSong.getName();
		if (newArtist.equals("")) newArtist = targetSong.getArtist();
		if (newAlbum.equals("")) newAlbum = targetSong.getAlbum();
		if (newAlbum.equals("")) newYear = targetSong.getYear();
		
		// Update song data
		targetSong.setName(newName);
		targetSong.setArtist(newArtist);
		targetSong.setAlbum(newAlbum);
		targetSong.setYear(newYear);
		
		// Remove song from the list and re-insert in its correct position
		songList.remove(targetIndex);
		auxillaryList.remove(targetIndex);
		if (songList.contains(targetSong)) {
			// If the newly edited song conflicts with another song in the list,
			// Then disallow the edit
			insertSong(copyOfTargetSong);
			// TODO: INSERT ERROR POPUP FOR INVALID EDIT
			return -1;
		} else {
			insertSong(targetSong);
		}
		
		return 0;
	}
	
	/**
	 * deletes the song with specified name and artist
	 * @param name
	 * @param artist
	 * @mutates undoSong and lastActionWasAdd, songList
	 */
	public void delete(String name, String artist) {
		Song targetSong = new Song(name, artist);
		int index = songList.indexOf(targetSong);
		if (index == -1) return; 
		
		songList.remove(index);
		auxillaryList.remove(index);
		return;
	}
	/**
	 * If the last action was an add, this method removes the previously added song from the list
	 * Otherwise, this method reverses the last delete or edit operation
	 * @mutates undoSong, lastActionWasAdd, songList
	 */
	
	
	/**
	 * writes the songList to a new text file
	 * @throws FileNotFoundException
	 */
	public void write() throws FileNotFoundException {
		PrintWriter pw = new PrintWriter("src/application/songtext.txt");
		for (int i = 0; i < songList.size(); i++) {
			pw.write(songList.get(i).getName() + "," +
					 songList.get(i).getArtist() + "," +
					 songList.get(i).getAlbum() + "," +
					 songList.get(i).getYear() + "\n");
			pw.flush();
		}pw.close();
	}
}
