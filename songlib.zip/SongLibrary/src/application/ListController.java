package application;
// Garis Silega and Jack Davitt

import java.io.File;
import java.io.FileNotFoundException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ListController {
		private Stage mainStage;
		private SongList songs;
	   @FXML         
	   ListView<String> listView;
	   @FXML
	   Label songTitle;
	   @FXML
	   Label songArtist;
	   @FXML
	   Label songAlbum;
	   @FXML
	   Label songYear;
	   @FXML
	   TextField inputTitle;
	   @FXML
	   TextField inputArtist;
	   @FXML
	   TextField inputAlbum;
	   @FXML
	   TextField inputYear;
	   @FXML
	   Button buttonAdd;
	   @FXML
	   Button buttonDelete;
	   @FXML
	   Button buttonEdit;
	   @FXML
	   Button buttonUndo;
	   
	   @FXML
	   Button buttonDoneAdd;
	   @FXML
	   Button buttonDoneEdit;
	   @FXML
	   Button buttonDoneDelete;
	   @FXML
	   Button buttonCancel;
	   ObservableList<String> obs;
	   
	   public void start(Stage mainStage, SongList songs) {
		   this.mainStage = mainStage;
		   this.songs = songs;
	      // create an ObservableList 
	      // from an ArrayList
		   obs = songs.auxillaryList;
	      listView.setItems(obs);
	      // select the first item 
	      // set listener for the items
	      try {
	    	  inputTitle.setVisible(false);	//make fields invisible
	    		inputArtist.setVisible(false);
	    		inputAlbum.setVisible(false);
	    		inputYear.setVisible(false);
				
				inputTitle.setEditable(false);	//make fields uneditable
	    		inputArtist.setEditable(false);
	    		inputAlbum.setEditable(false);
	    		inputYear.setEditable(false);
	    		
	    		inputTitle.setDisable(true);		//disable fields
	    		inputTitle.setDisable(true);
	    		inputTitle.setDisable(true);
	    		inputYear.setDisable(true);
	    		
	    	buttonAdd.setDisable(false);		//enable add/del/edit buttons
	    	buttonDelete.setDisable(false);
	    	buttonEdit.setDisable(false);
	    	
	    	
	    	buttonAdd.setVisible(true);		//enable add/del/edit buttons
	    	buttonDelete.setVisible(true);
	    	buttonEdit.setVisible(true);
	    	
	    	buttonDoneAdd.setVisible(true);		//enable add/del/edit buttons
	    	buttonDoneDelete.setVisible(false);
	    	buttonDoneEdit.setVisible(false);
	    	
	    	buttonDoneAdd.setDisable(true);
    		buttonDoneEdit.setDisable(true);
    		buttonDoneDelete.setDisable(true);
    		
	    	
	    	
	    buttonCancel.setVisible(false);
	    	buttonCancel.setDisable(true);
	    		
	    	/*	buttonDoneAdd.setDisable(false);
	    		buttonDoneEdit.setDisable(false);
	    		buttonDoneDelete.setDisable(false);
	    		cancel.setDisable(true);
	    		buttonDoneAdd.setDefaultButton(false);
	    		buttonDoneEdit.setDefaultButton(false);
	    		buttonDoneDelete.setDefaultButton(false);
	    		cancel.setCancelButton(false);*/
			songs.read();
			File file = new File("src/application/songtext.txt");
			if(file.length()!=0)listView.getSelectionModel().select(0);
			showSongDetail();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      listView
	        .getSelectionModel()
	        .selectedItemProperty()
	        .addListener(
	           (obs, oldVal, newVal) -> 
	               showSongDetail()); 
	   }
	   public void showSongDetail() { 
		   if(!songs.songList.isEmpty()) {
		   Song item = songs.songList.get(listView.getSelectionModel().getSelectedIndex());
		   songTitle.setText(item.name);
		   songArtist.setText(item.artist);
		   songAlbum.setText(item.album);
		   songYear.setText(item.year);
		   
		   inputTitle.setText("");
		   inputArtist.setText("");
		   inputYear.setText("");
		   inputAlbum.setText("");}
		   else {
			   songTitle.setText("");
			   songArtist.setText("");
			   songAlbum.setText("");
			   songYear.setText(""); 
		   }
		   
	   }
	   @FXML
	   public void addAppear() {
		   
     		
		  	buttonDoneAdd.setDisable(false);		//enable add/del/edit buttons
		    buttonDoneDelete.setDisable(true);
		    buttonDoneEdit.setDisable(true);
		    buttonCancel.setDisable(false);
		    
			 buttonDoneAdd.setVisible(true);		//enable add/del/edit buttons
		    	buttonDoneDelete.setVisible(false);
		    	buttonDoneEdit.setVisible(false);
		    	buttonCancel.setVisible(true);
		   
		   inputTitle.setVisible(true);	//make fields visible
      		inputArtist.setVisible(true);
      		inputAlbum.setVisible(true);
      		inputYear.setVisible(true);
   			
      		inputTitle.setEditable(true);	//make fields editable
   			inputArtist.setEditable(true);
      		inputAlbum.setEditable(true);
      		inputYear.setEditable(true);
      		
      		inputTitle.setDisable(false);		//disable fields
      		inputArtist.setDisable(false);
      		inputAlbum.setDisable(false);
      		inputYear.setDisable(false);
      		
      	buttonAdd.setVisible(false);		//enable add/del/edit buttons
      	buttonDelete.setVisible(false);
      	buttonEdit.setVisible(false);
      	
    

	   }
	   
	   @FXML
	   public void editAppear(){
		  
		   buttonDoneAdd.setDisable(true);		//enable add/del/edit buttons
	    	buttonDoneDelete.setDisable(true);
	    	buttonDoneEdit.setDisable(false);
	    	buttonCancel.setDisable(false);
	    	
	    	 buttonDoneAdd.setVisible(false);		//enable add/del/edit buttons
		    	buttonDoneDelete.setVisible(false);
		    	buttonDoneEdit.setVisible(true);
		    	buttonCancel.setVisible(true);
	    	
	    	inputTitle.setVisible(true);		//make fields visible
   		inputArtist.setVisible(true);
   		inputAlbum.setVisible(true);
   		inputYear.setVisible(true);

   		inputTitle.setEditable(true);	//make fields editable
   		inputArtist.setEditable(true);
   		inputAlbum.setEditable(true);
   		inputYear.setEditable(true);
   		
   		inputTitle.setDisable(false);	//enable fields
   		inputArtist.setDisable(false);
   		inputAlbum.setDisable(false);
   		inputYear.setDisable(false);
   		
   	buttonAdd.setDisable(true);		//disable add/del/edit buttons
   	buttonDelete.setDisable(true);
   	buttonEdit.setDisable(true);
   	
	   }
	   
	   @FXML
	   public void deleteAppear(){
		  
		   buttonDoneAdd.setDisable(true);		//enable add/del/edit buttons
	    	buttonDoneDelete.setDisable(false);
	    	buttonDoneEdit.setDisable(true);
	    	buttonCancel.setDisable(false);
	    	
	    	buttonDoneAdd.setVisible(false);		//enable add/del/edit buttons
	    	buttonDoneDelete.setVisible(true);
	    	buttonDoneEdit.setVisible(false);
	    	buttonCancel.setVisible(true);
	    	
	    inputTitle.setVisible(false);		//make fields visible
   		inputArtist.setVisible(false);
   		inputAlbum.setVisible(false);
   		inputYear.setVisible(false);

   		inputTitle.setEditable(false);	//make fields editable
   		inputArtist.setEditable(false);
   		inputAlbum.setEditable(false);
   		inputYear.setEditable(false);
   		
   		inputTitle.setDisable(true);	//enable fields
   		inputArtist.setDisable(true);
   		inputAlbum.setDisable(true);
   		inputYear.setDisable(true);
   		
   	buttonAdd.setDisable(true);		//disable add/del/edit buttons
   	buttonDelete.setDisable(true);
   	buttonEdit.setDisable(true);
	   }
	   @FXML
	   public void add() {
		   int index = 0;
		   try {
		   // Return if no field is present
		   if (inputTitle.getText().equals("")) return;
		   if (inputArtist.getText().equals("")) return;
		  Song newSong = new Song(inputTitle.getText(), inputArtist.getText(), 
				   inputAlbum.getText(), inputYear.getText());
		 songs.insertSong(newSong);
		 //  Song test = new Song(inputTitle.getText(), inputArtist.getText());
		   index = songs.songList.indexOf(newSong);
		  
		   listView.getSelectionModel().select(index);
		   songs.write();
		   System.out.println(index);
		   } catch (Exception e) {
			   return;
		   }
		   
	   }
	   @FXML
	   public void delete() {
		   int index = 0;
		  
		   try {
			   if (songs.songList.size() > 0) { 
				   String songName = songTitle.getText();
				   String artistName = songArtist.getText();
				   Song targetSong = new Song(songName, artistName);
				 index = songs.songList.indexOf(targetSong);
				   songs.delete(songName, artistName);
				   if (index ==songs.songList.size()-1)
				   {
				   listView.getSelectionModel().select(index);
				   		songs.write();
				   		return;
				   }
				   
			   } else if (songs.songList.size()>0){
				   listView.getSelectionModel().select(index+1);
				   songs.write();
			   		return;
			   }
			   else if (songs.auxillaryList.size() == 0) {
				   songs.write();
			   return;}
		   	}
		   catch (Exception e) {
			   return;
		   }
	   }
	   @FXML
	   public void edit() {
		   try {
			int k = listView.getSelectionModel().getSelectedIndex();
		   String songName = songTitle.getText();
		   String artistName = songArtist.getText();
		   String inName = inputTitle.getText();
		   String inArtist = inputArtist.getText();
		   String inAlbum = inputAlbum.getText();
		   String inYear = inputYear.getText();
		   if (songName.equals("")) songName = songs.songList.get(k).getName();
		   if (artistName.equals("")) artistName = songs.songList.get(k).getArtist();
		   songs.edit(songName ,artistName,
				 inName, inArtist, inAlbum, inYear);
		   int index = -1; 

		   for(Song song : songs.songList) {
				if(song.toString().compareTo(inName +" "+ inArtist)==0) {
					index = songs.songList.indexOf(song); 
				}}
		   if(index==-1) listView.getSelectionModel().select(k);
		   else
		   listView.getSelectionModel().select(index);
		   songs.write();
	   		return;}
		  
		    catch (Exception e) {
			   return;
		   }
		   }
	   
	   @FXML
	   public void cancel() {
		 inputTitle.setVisible(false);	//make fields visible
   		inputArtist.setVisible(false);
   		inputAlbum.setVisible(false);
   		inputYear.setVisible(false);
			
			inputTitle.setEditable(false);	//make fields uneditable
   		inputArtist.setEditable(false);
   		inputAlbum.setEditable(false);
   		inputYear.setEditable(false);
   		
   		inputTitle.setDisable(true);		//disable fields
   		inputArtist.setDisable(true);
   		inputAlbum.setDisable(true);
   		inputYear.setDisable(true);
   		
   	buttonAdd.setDisable(false);		//enable add/del/edit buttons
   	buttonDelete.setDisable(false);
   	buttonEdit.setDisable(false);
   	
	buttonAdd.setVisible(true);		//enable add/del/edit buttons
   	buttonDelete.setVisible(true);
   	buttonEdit.setVisible(true);
   		
   		buttonDoneAdd.setDisable(true);
   		buttonDoneEdit.setDisable(true);
   		buttonDoneDelete.setDisable(true);
   		buttonCancel.setDisable(true);
   		
   		buttonDoneAdd.setVisible(true);
   		buttonDoneEdit.setVisible(true);
   		buttonDoneDelete.setVisible(true);
   		buttonCancel.setVisible(true);
 
		   
	   }
	   
}
			   

	   